def create_relationship_name(fromTable,fromColumn,toTable,toColumn):
        """
        
    This is a helper function which more easily creates the relationship name
    
    """
        return "'" + fromTable + "'[" + fromColumn + "] -> '" + toTable + '[' + toColumn + ']'