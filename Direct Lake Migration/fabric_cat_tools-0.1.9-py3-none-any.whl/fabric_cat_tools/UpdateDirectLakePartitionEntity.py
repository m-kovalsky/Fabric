import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM

def update_direct_Lake_partition_entity(datasetName, tableName, entityName, workspaceName = None):

    """
    
    This function updates the source table in the lakehouse for a given table in a Direct Lake semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        tableName: The table whose source is to be updated.
        entityName: The name of the lakehouse table.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    from .GetLakehouseTables import get_lakehouse_tables
    from .GetDirectLakeLakehouse import get_direct_lake_lakehouse
    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)   

    datasetId = resolve_dataset_id(datasetName, workspaceName) 

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake. This function is only applicable to Direct Lake semantic models.")
        return
    else:
        lakehouseName, lakehouseId = get_direct_lake_lakehouse(datasetName, workspaceName)

        lt = get_lakehouse_tables(lakehouseName, workspaceName) # put lakehouseId
        lt_filt = lt[lt['Table Name'] == entityName]
    
    if len(lt_filt) == 0:
        print(f"The '{lakehouseName}' used by the '{datasetName}' semantic model has no table named '{entityName}'.")
    else:
        tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

        print(f"Updating the '{datasetName}' semantic model...")
        m = tom_server.Databases[datasetId].Model
        try:
            m.Tables[tableName].Partitions[0].EntityName = entityName
            m.SaveChanges()
            print(f"The '{tableName}' table in the '{datasetName}' semantic model has been updated to point to the '{entityName}' table in the lakehouse.")
        except:
            print(f"ERROR: ...")



    

