import sempy
import sempy.fabric as fabric
import pandas as pd
from pyspark.sql import SparkSession

def get_lakehouse_tables(lakehouseName = None):

    """
    
    This function outputs a dataframe containing a list of tables in a lakehouse.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Lakehouse Name
            Table Name
            
    """

    df = pd.DataFrame(columns=['Lakehouse Name', 'Table Name'])

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        dfItems = fabric.list_items()
        dfItems_filt = dfItems[(dfItems['Id'] == lakehouseId) & (dfItems['Type'] == 'Lakehouse')]
        lakehouseName = dfItems_filt['Display Name'].iloc[0]

    spark = SparkSession.builder.getOrCreate()
    
    tables = spark.sql(f"SHOW TABLES IN {lakehouseName}").collect()

    for t in tables:
        tName = t['tableName']
                
        new_data = {'Lakehouse Name': lakehouseName, 'Table Name': tName}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df