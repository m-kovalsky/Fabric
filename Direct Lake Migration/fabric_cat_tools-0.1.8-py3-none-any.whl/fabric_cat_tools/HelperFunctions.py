import sempy
import sempy.fabric as fabric

def create_relationship_name(fromTable, fromColumn, toTable, toColumn):

    return "'" + fromTable + "'[" + fromColumn + "] -> '" + toTable + '[' + toColumn + ']'

def create_daxfullobjectname(a,b):
    
    return "'" + a + "'[" + b + "]"

def resolve_dataset_id(datasetName, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == datasetName) & (dfI['Type'] == 'SemanticModel')]
    datasetId = dfI_filt['Id'].iloc[0]

    return datasetId

def resolve_dataset_name(datasetId, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Id'] == datasetId) & (dfI['Type'] == 'SemanticModel')]
    datasetName = dfI_filt['Display Name'].iloc[0]

    return datasetName

def resolve_lakehouse_name(lakehouseId, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Id'] == lakehouseId) & (dfI['Type'] == 'Lakehouse')]
    lakehouseName = dfI_filt['Display Name'].iloc[0]

    return lakehouseName

def resolve_lakehouse_id(lakehouseName, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == lakehouseName) & (dfI['Type'] == 'Lakehouse')]
    lakehouseId = dfI_filt['Id'].iloc[0]

    return lakehouseId