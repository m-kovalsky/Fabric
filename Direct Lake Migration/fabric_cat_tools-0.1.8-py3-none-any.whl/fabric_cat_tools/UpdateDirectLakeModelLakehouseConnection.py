import sempy
import sempy.fabric as fabric
import pandas as pd
import Microsoft.AnalysisServices.Tabular as TOM

def update_direct_lake_model_lakehouse_connection(datasetName, lakehouseName = None, workspaceName = None):

    """
    
    This function updates the connection of a Direct Lake model to a different lakehouse.

    Parameters:

        datasetName: The name of the semantic model.
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.        
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    from .GetSharedExpression import get_shared_expression
    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import resolve_lakehouse_name

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']
    
    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake. This function is only applicable to Direct Lake semantic models.")
    else:
        tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
        datasetId = resolve_dataset_id(datasetName, workspaceName)

        shEx = get_shared_expression(lakehouseName,workspaceName)

        print(f"Updating the '{datasetName}' semantic model...")
        m = tom_server.Databases[datasetId].Model
        try:
            m.Expressions['DatabaseQuery'].Expression = shEx
            m.SaveChanges()
            print(f"The expression in the '{datasetName}' semantic model has been updated to point to the '{lakehouseName}' lakehouse.")
        except:
            print(f"ERROR: The expression in the '{datasetName}' semantic model was not updated.")



    

