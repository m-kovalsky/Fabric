import sempy
import sempy.fabric as fabric
import pandas as pd
import re
from pyspark.sql import SparkSession

def migrate_calc_tables_to_lakehouse(datasetName,newDatasetName):

    dfC = fabric.list_columns(datasetName)
    dfC['Full Column Name'] = "'" + dfC['Table Name'] + "'[" + dfC['Column Name'] + "]"
    dfC_filt = dfC[dfC['Type'] == 'Calculated']
    dfP = fabric.list_partitions(datasetName)
    dfP_filt = dfP[dfP['Source Type'] == 'Calculated']
    spark = SparkSession.builder.getOrCreate()

    for i,r in dfP_filt.iterrows():
        tName = r['Table Name']
        query = r['Query']
        daxquery = 'EVALUATE \n' + query

        try:
            df = fabric.evaluate_dax(newDatasetName,daxquery)

            # Update column names for non-field parameters
            if query.find('NAMEOF') == -1:
                for old_column_name in df.columns:
                    pattern = r"\[([^\]]+)\]"
                    
                    matches = re.findall(pattern, old_column_name) 
                    new_column_name = matches[0]
                
                    df.rename(columns={old_column_name: new_column_name}, inplace=True)

                    # Update data types for lakehouse columns
                    dfC_type = dfC[(dfC['Table Name'] == tName) & (dfC['Column Name'] == new_column_name)]
                    dataType = dfC_type['Data Type'].iloc[0]                    
                    
                    if dataType == 'Int64':
                        df[new_column_name] = df[new_column_name].astype(int)
                    elif dataType in ['Decimal', 'Double']:
                        df[new_column_name] = df[new_column_name].astype(float)
                    elif dataType == 'Boolean':
                        df[new_column_name] = df[new_column_name].astype(bool)
                    elif dataType == 'DateTime':
                        df[new_column_name] = pd.to_datetime(df[new_column_name])                                        
            else:
                second_column_name = df.columns[1]
                third_column_name = df.columns[2]
                df[third_column_name] = df[third_column_name].astype(int)

                # Remove calc columns from field parameters
                mask = df[second_column_name].isin(dfC_filt['Full Column Name'])
                df = df[~mask]

            delta_table_name = tName.replace(' ','_')

            spark_df = spark.createDataFrame(df)
            spark_df.write.mode('overwrite').format('delta').saveAsTable(delta_table_name)
            print(f"Calculated table '{tName}' has been created as delta table '{delta_table_name.lower()}' in the lakehouse.")
        except:
            print(f"Failed to create calculated table '{tName}' as a delta table in the lakehouse.")