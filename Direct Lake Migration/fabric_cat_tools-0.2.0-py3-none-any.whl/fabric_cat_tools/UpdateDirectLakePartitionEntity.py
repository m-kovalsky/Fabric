import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM

def update_direct_Lake_partition_entity(datasetName, tableName, entityName, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function updates the source table in the lakehouse for a given table in a Direct Lake semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        tableName: The table whose source is to be updated. This can be a single text value or an array.
        entityName: The name of the lakehouse table to which the semantic model table will be repointed. This can be a single text value or an array. If tableName is an array then entityName must also be an array.
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse name used in the Direct Lake semantic model.
        lakehouseWorkspaceName: An optional parameter to set the workspace in which the lakehouse resides. If you specify a lakehouseName you must specify a lakehouseWorkspaceName.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        update_direct_Lake_partition_entity(
            datasetName = 'AdventureWorks'
            ,tableName = 'Internet Sales'
            ,entityName = 'Fact_InternetSales'
            #,workspaceName = '' 
            )

        update_direct_Lake_partition_entity(
            datasetName = 'AdventureWorks'
            ,tableName = ['Internet Sales', 'Geography']
            ,entityName = ['Fact_InternetSales', 'DimGeography']
            #,workspaceName = '' 
            )
    """

    from .GetLakehouseTables import get_lakehouse_tables
    #from .GetDirectLakeLakehouse import get_direct_lake_lakehouse
    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import resolve_lakehouse_name

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)   

    if lakehouseWorkspaceName is None and lakehouseName is not None:
        print(f"ERROR: If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName is None:
        lakehouseWorkspaceName = workspaceName

    if lakehouseName is None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, lakehouseWorkspaceName)    

    # Check if tableName & columnName are both arrays or string text value
    if isinstance(tableName, list) & isinstance(entityName, str):
        print(f"ERROR: If the 'tableName' parameter is an array, the 'entityName' parameter must also be an array.")
        return
    elif isinstance(tableName, str) & isinstance(entityName, list):
        print(f"ERROR: If the 'tableName' parameter is a single text value, the 'entityName' parameter must also be a single text value.")
        return
    elif isinstance(tableName, list) & isinstance(entityName, list) & (len(tableName) != len(entityName)):
        print(f"ERROR: The 'tableName' and 'entityName' arrays must be of equal length.")
    

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    if isinstance(tableName, str):
        dfP_filt = dfP[(dfP['Table Name'] == tableName) & (dfP['Mode'] == 'DirectLake')]

        tableName = [tableName]
        entityName = [entityName]
    elif isinstance(tableName, list):
        dfP_filt = dfP[(dfP['Table Name'].isin(tableName)) & (dfP['Mode'] == 'DirectLake')]
    
    tblent = pd.DataFrame({
        'Table Name': tableName,
        'Entity Name': entityName
    })

    if len(dfP_filt) == 0:
        print(f"ERROR: The '{tableName}' table in the '{datasetName}' semantic model is not in Direct Lake mode. This function is only applicable to tables in Direct Lake mode.")
        return

    #lakehouseName, lakehouseId = get_direct_lake_lakehouse(datasetName, workspaceName)

    lt = get_lakehouse_tables(lakehouseName, lakehouseWorkspaceName)

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    datasetId = resolve_dataset_id(datasetName, workspaceName)
    print(f"Updating the '{datasetName}' semantic model...")
    m = tom_server.Databases[datasetId].Model

    for i, r in dfP_filt.iterrows():
        tName = r['Table Name']
        pName = r['Partition Name']
        tblent_filt = tblent[tblent['Table Name'] == tName]
        eName = tblent_filt['Entity Name'].iloc[0]
    
        lt_filt = lt[lt['Table Name'] == eName]
    
        if len(lt_filt) == 0:
            print(f"ERROR: The '{lakehouseName}' used by the '{datasetName}' semantic model has no table named '{eName}'. The '{tName}' table was not updated.")
        else:
            shEx = m.Expressions['DatabaseQuery']
            ep = TOM.EntityPartitionSource()
            ep.EntityName = eName
            ep.ExpressionSource = shEx
            
            try:
                m.Tables[tName].Partitions[pName].Source = ep                
                print(f"The '{tName}' table in the '{datasetName}' semantic model has been updated to point to the '{eName}' table in the lakehouse.")
            except:
                print(f"ERROR: The '{tName}' table in the '{datasetName}' semantic model has not been updated.")

    m.SaveChanges()



    

