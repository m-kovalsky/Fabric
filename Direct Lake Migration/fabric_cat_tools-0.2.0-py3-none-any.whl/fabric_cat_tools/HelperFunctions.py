import sempy
import sempy.fabric as fabric

def create_daxfullobjectname(a,b):
    
    return "'" + a + "'[" + b + "]"

def create_relationship_name(fromTable, fromColumn, toTable, toColumn):

    return create_daxfullobjectname(fromTable, fromColumn) + ' -> ' + create_daxfullobjectname(toTable, toColumn)

def resolve_report_id(reportName, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'Report'
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == reportName) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Id'].iloc[0]

    return obj

def resolve_report_name(reportId, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'Report'
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Id'] == reportId) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_dataset_id(datasetName, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'SemanticModel'
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == datasetName) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Id'].iloc[0]

    return obj

def resolve_dataset_name(datasetId, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'SemanticModel'
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Id'] == datasetId) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_lakehouse_name(lakehouseId, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'Lakehouse'
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Id'] == lakehouseId) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_lakehouse_id(lakehouseName, workspaceName = None):
    
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    objectType = 'Lakehouse'    
    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == lakehouseName) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Id'].iloc[0]

    return obj