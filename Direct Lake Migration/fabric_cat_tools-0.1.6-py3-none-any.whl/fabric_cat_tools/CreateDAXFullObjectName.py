# This is a helper function which more easily creates DAX full object names (table + column)
def create_daxfullobjectname(a,b):
        return "'" + a + "'[" + b + "]"