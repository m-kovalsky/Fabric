import sempy
import sempy.fabric as fabric

def clear_cache(datasetName, workspaceName = None):

    """
    
    This function clears the cache of a semantic model.

    Parameters:
        
        datasetName: This is name of the semantic model.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfD = fabric.list_datasets(workspace = workspaceName)
    dfD_filt = dfD[dfD['Dataset Name'] == datasetName]
    rowCount = len(dfD_filt)

    if rowCount == 1:
        datasetID = dfD_filt["Dataset ID"].iloc[0]
        xmla = f"""
                <ClearCache xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">  
                    <Object>  
                        <DatabaseID>{datasetID}</DatabaseID>  
                    </Object>  
                </ClearCache>
                """
        fabric.execute_xmla(dataset = datasetName,xmla_command=xmla, workspace = workspaceName)

        outputtext = f"Cache cleared for the '{datasetName}' semantic model."

    else:
        outputtext = f"The '{datasetName}' semantic model does not exist in the '{workspaceName}' workspace."

    return outputtext
