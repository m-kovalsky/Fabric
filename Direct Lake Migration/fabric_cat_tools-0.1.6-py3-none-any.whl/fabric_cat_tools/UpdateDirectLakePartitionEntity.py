import sempy
import sempy.fabric as fabric
import pandas as pd
from sempy.fabric._cache import _get_or_create_workspace_client
from sempy.fabric._client._connection_mode import ConnectionMode
import Microsoft.AnalysisServices.Tabular as TOM

# This function generates the shared expression statement for a given lakehouse and its SQL endpoint

def update_direct_Lake_partition_entity(datasetName, tableName, entityName, workspaceName = None):

    """
    
    This function updates the source table in the lakehouse for a given table in a Direct Lake semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        tableName: The table whose source is to be updated.
        entityName: The name of the lakehouse table.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    from .GetLakehouseTables import get_lakehouse_tables
    from .GetDirectLakeLakehouse import get_direct_lake_lakehouse

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)    

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake. This function is only applicable to Direct Lake semantic models.")
        return
    else:
        lakehouseName, lakehouseId = get_direct_lake_lakehouse(datasetName, workspaceName)

        lt = get_lakehouse_tables(lakehouseName)
        lt_filt = lt[lt['Table Name'] == entityName]
    
    if len(lt_filt) == 0:
        print(f"The '{lakehouseName}' used by the '{datasetName}' semantic model has no table named '{entityName}'.")
    else:
        tom_server = _get_or_create_workspace_client(workspaceName).get_dataset_client(datasetName, ConnectionMode.XMLA)._get_connected_dataset_server(readonly=False)

        for d in tom_server.Databases:
            if d.Name == datasetName:
                print(f"Updating the '{datasetName}' semantic model...")
                m = d.Model
                try:
                    m.Tables[tableName].Partitions[0].EntityName = entityName
                    m.SaveChanges()
                    print(f"The '{tableName}' table in the '{datasetName}' semantic model has been updated to point to the '{entityName}' table in the lakehouse.")
                except:
                    print(f"ERROR: ...")



    

