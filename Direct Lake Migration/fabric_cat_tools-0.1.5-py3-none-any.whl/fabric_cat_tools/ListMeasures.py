import sempy
import sempy.fabric as fabric
from sempy.fabric._cache import _get_or_create_workspace_client
import pandas as pd

def list_measures(datasetName, workspaceName = None):

    if workspaceName == None:
        workspaceID = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceID)    

    workspace_client = _get_or_create_workspace_client(workspaceName)
    ds = workspace_client.get_dataset(datasetName)
    m = ds.Model

    df = pd.DataFrame(columns=['Measure Name', 'Table Name', 'Hidden', 'Format String', 'Display Folder', 'Expression', 'Description'])

    for t in m.Tables:
        for ms in t.Measures:
            new_data = {'Measure Name': ms.Name, 'Table Name': t.Name, 'Hidden': ms.IsHidden, 'Format String': ms.FormatString, 'Display Folder': ms.DisplayFolder, 'Expression': ms.Expression, 'Description': ms.Description}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    df['Hidden'] = df['Hidden'].astype(bool)
    
    return df