import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
from sempy.fabric._cache import _get_or_create_workspace_client
from sempy.fabric._client._connection_mode import ConnectionMode
import Microsoft.AnalysisServices.Tabular as TOM
from sempy.fabric._client import DatasetXmlaClient
from notebookutils import mssparkutils
import System

def add_tables_columns(datasetName, newDatasetName, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function adds tables and columns (and only their basic properties) to the new semantic model
    based on the original semantic model. This only includes regular tables (not calc tables or calc groups).

    Parameters:
        
        datasetName: This is name of the old semantic model.
        newDatasetName: This is name of the new semantic model.
        workspaceName: An optional parameter to set the workspace for the semantic models. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse to tie the new Direct Lake semantic model.
        lakehouseWorkspaceName: The workspace in which the lakehouse resides. This is required if you set the lakehouseName parameter.

    Returns:

        This function returns a printout detailing which objects have been migrated and any failures.
    """

    from .ListTables import list_tables
    from .GetSharedExpression import get_shared_expression

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseWorkspaceName == None & lakehouseName != None:
        print(f"If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName == None:
        lakehouseWorkspaceName = workspaceName

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        dfI = fabric.list_items(workspace = workspaceName)
        dfI_filt = dfI[(dfI['Id'] == lakehouseId) & (dfI['Type'] == 'Lakehouse')]
        lakehouseName = dfI_filt['Display Name'].iloc[0]

    tom_server = _get_or_create_workspace_client(workspaceName).get_dataset_client(newDatasetName, ConnectionMode.XMLA)._get_connected_dataset_server(readonly=False)

    # Check that lakehouse is attached to the notebook
    mounts = pd.DataFrame(mssparkutils.fs.mounts())
    mounts_filt = mounts[mounts['storageType'] == 'Lakehouse']

    # Run if lakehouse is attached to the notebook or a lakehouse & lakehouse workspace are specified
    if len(mounts_filt) == 1 or (lakehouseName is not None and lakehouseWorkspaceName is not None):
        print('Lakehouse attached to notebook\n')

        shEx = get_shared_expression(lakehouseName, lakehouseWorkspaceName)

        dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
        dfT = list_tables(datasetName, workspaceName)

        for d in tom_server.Databases:
            if d.Name == newDatasetName:
                print(f"Updating '{d.Name}' based on '{datasetName}'...")
                m = d.Model
                print(f"\nCreating shared expression parameter...")
                exp = TOM.NamedExpression()
                eName = 'DatabaseQuery'
                exp.Name = eName
                exp.Kind = TOM.ExpressionKind.M
                exp.Expression = shEx
                if not any(e.Name == eName for e in m.Expressions):
                    m.Expressions.Add(exp)
                    print(f"'{eName}' shared expression has been added.")

                for tName in dfC['Table Name'].unique():
                    tType = dfT.loc[(dfT['Name'] == tName), 'Type'].iloc[0]
                    tDC = dfC.loc[(dfC['Table Name'] == tName), 'Data Category'].iloc[0]
                    tDesc = dfC.loc[(dfC['Table Name'] == tName), 'Description'].iloc[0]

                    # Create the table with its columns for regular tables that do not already exist in the model
                    if tType == 'Table' and not any(t.Name == tName for t in m.Tables):
                        tbl = TOM.Table()        
                        tbl.Name = tName
                        tbl.DataCategory = tDC
                        tbl.Description = tDesc

                        ep = TOM.EntityPartitionSource()
                        ep.Name = tName
                        ep.EntityName = tName.replace(' ', '_') #lakehouse table names use underscores instead of spaces
                        ep.ExpressionSource = exp

                        part = TOM.Partition()
                        part.Name = tName
                        part.Source = ep
                        part.Mode = TOM.ModeType.DirectLake

                        tbl.Partitions.Add(part)

                        columns_in_table = dfC.loc[dfC['Table Name'] == tName, 'Column Name'].unique()
                
                        print(f"\nCreating columns for '{tName}' table...")           
                        for cName in columns_in_table:
                            scName = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Source'].iloc[0]
                            cType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Type'].iloc[0]
                            cHid = bool(dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Hidden'].iloc[0])
                            cDataType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Data Type'].iloc[0]

                            if cType == 'Data' and not any(t.Name == tName and c.Name == cName for t in m.Tables for c in t.Columns):
                                col = TOM.DataColumn()
                                col.Name = cName
                                col.IsHidden = cHid
                                col.SourceColumn = scName.replace(' ', '_') #lakehouse column names use underscores instead of spaces
                                col.DataType = System.Enum.Parse(TOM.DataType, cDataType)

                                tbl.Columns.Add(col)
                                print(f"The '{tName}'[{cName}] column has been added.")
                
                        m.Tables.Add(tbl)
                        print(f"The '{tName}' table has been added.")

                m.SaveChanges()
                print(f"\nAll regular tables and columns have been added to the model.")

    else:
        print('Lakehouse not attached to notebook. Please add your lakehouse to this notebook.')
        print(f"In the 'Explorer' window to the left, click 'Lakehouses' to add your lakehouse to this notebook")
        print(f"\nLearn more here: https://learn.microsoft.com/fabric/data-engineering/lakehouse-notebook-explore#add-or-remove-a-lakehouse")