import sempy
import sempy.fabric as fabric

def report_rebind_all(oldDatasetName, newDatasetName, workspaceName = None):

    from .GetReportsLineage import get_reports_lineage
    from .ReportRebind import report_rebind

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    rptlin = get_reports_lineage(workspaceName)

    for i, r in rptlin.iterrows():
        rptName = r['Report Name']
        dName = r['Dataset Name']

        if dName == oldDatasetName:
            report_rebind(rptName, newDatasetName, workspaceName)

