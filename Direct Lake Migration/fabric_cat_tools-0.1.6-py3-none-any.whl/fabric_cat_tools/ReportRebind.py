import sempy
import sempy.fabric as fabric
import json, requests, pandas as pd

# reportName: this is the report you want to rebind the dataset
# datasetName: this is the dataset to which you want to rebind the report

# This function rebinds a report to the specified semantic model

def report_rebind(reportName, datasetName, workspaceName = None):

    """
    
    This function rebinds a report to the specified semantic model.

    Parameters:

        reportName: The report to be rebinded.
        datasetName: The semantic model to rebind to the report.
        workspaceName: An optional parameter to set the workspace in which the report and semantic model reside. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    client = fabric.PowerBIRestClient()
    itemList = fabric.list_items(workspace = workspaceName)

    # Get report ID
    itemListFilt = itemList[(itemList['Display Name'] == reportName) & (itemList['Type'] == 'Report')]
    reportId = itemListFilt['Id'].iloc[0]

    # Get dataset ID for rebinding
    itemListFilt = itemList[(itemList['Display Name'] == datasetName) & (itemList['Type'] == 'SemanticModel')]
    datasetId = itemListFilt['Id'].iloc[0]

    # Prepare API
    request_body = {
        'datasetId': datasetId
    }

    response = client.post(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/Rebind",json=request_body)

    if response.status_code == 200:
        print('POST request successful')
        print(f"The '{reportName}' report has been successfully rebinded to the '{datasetName}' semantic model.")
    else:
        print(f"POST request failed with status code: {response.status_code}")