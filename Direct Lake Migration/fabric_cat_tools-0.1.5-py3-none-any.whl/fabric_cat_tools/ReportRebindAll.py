import sempy
import sempy.fabric as fabric

# This function loops through all reports connected to a semantic model and rebinds them to a new semantic model

def report_rebind_all(datasetName, newDatasetName, workspaceName = None):

    """
    
    This function rebinds all reports which are bound to a specific semantic model to a different semantic model.

    Limitations:

        This function uses the GetReportsLineage function. That function uses the CreateItemDefinition Fabric API which 
        does not support encrypted items. Therefore, reports which have specific Sensitivity Labels are not supported 
        by this function.

    Parameters:

        datasetName: The old semantic model name.
        newDatasetName: The new semantic model name.
        workspaceName: An optional parameter to set the workspace in which the reports and semantic models reside. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .GetReportsLineage import get_reports_lineage
    from .ReportRebind import report_rebind

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    rptlin = get_reports_lineage(workspaceName)

    for i, r in rptlin.iterrows():
        rptName = r['Report Name']
        dName = r['Dataset Name']

        if dName == datasetName:
            report_rebind(rptName, newDatasetName, workspaceName)

