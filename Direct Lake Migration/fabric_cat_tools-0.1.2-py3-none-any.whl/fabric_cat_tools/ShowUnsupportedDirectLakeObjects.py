import sempy
import sempy.fabric as fabric
import pandas as pd

def show_unsupported_direct_lake_objects(datasetName):

    from .ListTables import list_tables
    from .CreateDAXFullObjectName import create_daxfullobjectname

    dfT = list_tables(datasetName)
    dfC = fabric.list_columns(datasetName)
    dfR = fabric.list_relationships(datasetName)

    # Calc tables & calc groups
    dfT_filt = dfT[dfT['Type'] != 'Table']
    dfT_filt.rename(columns={'Name': 'Table Name'}, inplace=True)
    t = dfT_filt[['Table Name', 'Type']]

    # Calc columns
    dfC_filt = dfC[dfC['Type'] == 'Calculated']
    c = dfC_filt[['Table Name', 'Column Name', 'Type', 'Source']]

    # Relationships
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
    dfR['From Object'] = create_daxfullobjectname(dfR['From Table'], dfR['From Column'])
    dfR['To Object'] = create_daxfullobjectname(dfR['To Table'], dfR['To Column'])
    merged_from = pd.merge(dfR, dfC, left_on='From Object', right_on='Column Object', how='left')
    merged_to = pd.merge(dfR, dfC, left_on='To Object', right_on='Column Object', how='left')

    dfR['From Column Data Type'] = merged_from['Data Type']
    dfR['To Column Data Type'] = merged_to['Data Type']

    dfR_filt = dfR[((dfR['From Column Data Type'] == 'DateTime') | (dfR['To Column Data Type'] == 'DateTime')) | (dfR['From Column Data Type'] != dfR['To Column Data Type'])]
    r = dfR_filt[['From Table', 'From Column', 'To Table', 'To Column', 'From Column Data Type', 'To Column Data Type']]

    return display(t), display(c), display(r)