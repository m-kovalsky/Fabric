import sempy
import sempy.fabric as fabric
import pandas as pd
from notebookutils import mssparkutils

def get_lakehouse_tables(lakehouseName = None, workspaceName = None):

    """
    
    This function outputs a dataframe containing a list of tables in a lakehouse.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        workspaceName: An optional parameter to indicate the workspace in which the lakehouse resides.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Lakehouse Name
            Table Name
            
    """

    from .HelperFunctions import resolve_lakehouse_id

    df = pd.DataFrame(columns=['Lakehouse Name', 'Table Name'])

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

    tables = mssparkutils.fs.ls(f'abfss://{workspaceId}@onelake.dfs.fabric.microsoft.com/{lakehouseId}/Tables')

    for t in tables:
        tName = t.name
                
        new_data = {'Lakehouse Name': lakehouseName, 'Table Name': tName}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df
 
    