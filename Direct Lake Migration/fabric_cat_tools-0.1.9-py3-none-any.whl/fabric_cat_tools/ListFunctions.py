import sempy
import sempy.fabric as fabric
import pandas as pd

def list_tables(datasetName, workspaceName = None):

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    datasetId = resolve_dataset_id(datasetName, workspaceName)
    tom_server = fabric.create_tom_server(readonly=True, workspace=workspaceName)
    m = tom_server.Databases[datasetId].Model

    df = pd.DataFrame(columns=['Name', 'Type', 'Hidden', 'Data Category', 'Description', 'Refresh Policy', 'Source Expression'])

    for t in m.Tables:
        tableType = "Table"
        rPolicy = bool(t.RefreshPolicy)
        sourceExpression = None
        if str(t.CalculationGroup) != "None":
            tableType = "Calculation Group"
        else:
            for p in t.Partitions:
                if str(p.SourceType) == "Calculated":
                    tableType = "Calculated Table"

        if rPolicy:
            sourceExpression = t.RefreshPolicy.SourceExpression

        new_data = {'Name': t.Name, 'Type': tableType, 'Hidden': t.IsHidden, 'Data Category': t.DataCategory, 'Description': t.Description, 'Refresh Policy': rPolicy, 'Source Expression': sourceExpression}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df

def list_annotations(datasetName, workspaceName = None):

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    datasetId = resolve_dataset_id(datasetName, workspaceName)
    tom_server = fabric.create_tom_server(readonly=True, workspace=workspaceName)
    m = tom_server.Databases[datasetId].Model

    df = pd.DataFrame(columns=['Object Name', 'Parent Object Name', 'Object Type', 'Annotation Name', 'Annotation Value'])

    mName = m.Name
    for a in m.Annotations:        
        objectType = 'Model'
        aName = a.Name
        aValue = a.Value
        new_data = {'Object Name': mName, 'Parent Object Name': "N/A", 'Object Type': objectType,'Annotation Name': aName, 'Annotation Value': aValue}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for t in m.Tables:
        objectType = 'Table'
        tName = t.Name
        for ta in t.Annotations:
            taName = ta.Name
            taValue = ta.Value
            new_data = {'Object Name': tName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': taName, 'Annotation Value': taValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        for p in t.Partitions:
            pName = p.Name
            objectType = 'Partition'
            for pa in p.Annotations:
                paName = paName
                paValue = paValue
                new_data = {'Object Name': pName, 'Parent Object Name': tName, 'Object Type': objectType,'Annotation Name': paName, 'Annotation Value': paValue}
                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        for c in t.Columns:
            objectType = 'Column'
            cName = c.Name            
            for ca in c.Annotations:
                caName = ca.Name
                caValue = ca.Value
                new_data = {'Object Name': cName, 'Parent Object Name': tName, 'Object Type': objectType,'Annotation Name': caName, 'Annotation Value': caValue}
                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        for ms in t.Measures:
            objectType = 'Measure'
            measName = ms.Name
            for ma in ms.Annotations:
                maName = ma.Name
                maValue = ma.Value
                new_data = {'Object Name': measName, 'Parent Object Name': tName, 'Object Type': objectType,'Annotation Name': maName, 'Annotation Value': maValue}
                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        for h in t.Hierarchies:
            objectType = 'Hierarchy'
            hName = h.Name
            for ha in h.Annotations:
                haName = ha.Name
                haValue = ha.Value
                new_data = {'Object Name': hName, 'Parent Object Name': tName, 'Object Type': objectType,'Annotation Name': haName, 'Annotation Value': haValue}
                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for d in m.DataSources:
        dName = d.Name
        objectType = 'Data Source'
        for da in d.Annotations:
            daName = da.Name
            daValue = da.Value
            new_data = {'Object Name': dName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': daName, 'Annotation Value': daValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for r in m.Relationships:
        rName = r.Name
        objectType = 'Relationship'
        for ra in r.Annotations:
            raName = ra.Name
            raValue = ra.Value
            new_data = {'Object Name': rName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': raName, 'Annotation Value': raValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for cul in m.Cultures:
        culName = cul.Name
        objectType = 'Translation'
        for cula in cul.Annotations:
            culaName = cula.Name
            culaValue = cula.Value
            new_data = {'Object Name': culName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': culaName, 'Annotation Value': culaValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for e in m.Expressions:
        eName = e.Name
        objectType = 'Expression'
        for ea in e.Annotations:
            eaName = ea.Name
            eaValue = ea.Value
            new_data = {'Object Name': eName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': eaName, 'Annotation Value': eaValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for per in m.Perspectives:
        perName = per.Name
        objectType = 'Perspective'
        for pera in per.Annotations:
            peraName = pera.Name
            peraValue = pera.Value
            new_data = {'Object Name': perName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': peraName, 'Annotation Value': peraValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    for rol in m.Roles:
        rolName = rol.Name
        objectType = 'Role'
        for rola in rol.Annotations:
            rolaName = rola.Name
            rolaValue = rola.Value
            new_data = {'Object Name': rolName, 'Parent Object Name': mName, 'Object Type': objectType,'Annotation Name': rolaName, 'Annotation Value': rolaValue}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df