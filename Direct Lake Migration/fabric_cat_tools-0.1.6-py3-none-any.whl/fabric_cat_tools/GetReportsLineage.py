import sempy
import sempy.fabric as fabric
import pandas as pd
import base64
import json

def get_reports_lineage(workspaceName = None):

    """
    
    This function obtains the lineage between reports and semantic models within a given workspace.

    Limitations:

        This function uses the CreateItemDefinition Fabric API which does not support encrypted items. Therefore,
        reports which have specific Sensitivity Labels are not supported by this function.

    Parameters:
            
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Report Name
            Report ID
            Dataset Name
            Dataset ID
            Connection String
    """

    df = pd.DataFrame(columns=['Report Name', 'Report ID', 'Dataset Name', 'Dataset ID', 'Connection String'])

    client = fabric.FabricRestClient()
    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)
        
    itemList = fabric.list_items(workspace = workspaceName)
    itemListFilt = itemList[itemList['Type'] == 'Report']

    for index, row in itemListFilt.iterrows():
        reportId = row['Id']
        reportName = row['Display Name']
        try:
            response = client.post(f"/v1/workspaces/{workspaceId}/items/{reportId}/getDefinition")
            df_items = pd.json_normalize(response.json()['definition']['parts'])
            df_items_filt = df_items[df_items['path'] == 'definition.pbir']
            payload = df_items_filt['payload'].iloc[0]
            definitionFile = base64.b64decode(payload).decode('utf-8')
            definitionJson = json.loads(definitionFile)['datasetReference']['byConnection']

            datasetId = definitionJson['pbiModelDatabaseName']
            connString = definitionJson['connectionString']
            itemListFilt = itemList[(itemList['Id'] == datasetId) & (itemList['Type'] == 'SemanticModel')]
            datasetName = itemListFilt['Display Name'].iloc[0]
        except:
            datasetId = None
            datasetName = None
            connString = None

        new_data = pd.DataFrame({'Report Name': reportName, 'Report ID': reportId, 'Dataset Name': datasetName, 'Dataset ID': datasetId, 'Connection String': connString}, index=[0])
        df = pd.concat([df, new_data], ignore_index=True)
    
    return df