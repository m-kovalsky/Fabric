from ._model import TOMWrapper, connect_semantic_model

__all__ = ["TOMWrapper", "connect_semantic_model"]
