import sempy
import sempy.fabric as fabric
import pandas as pd
import re

def get_direct_lake_lakehouse(datasetName, workspaceName = None):

    """
    
    This function identifies the lakehouse used by a Direct Lake semantic model.

    Parameters:
        
        datasetName: The name of the semantic model. 
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns the lakehouse name and ID.
    """

    from .HelperFunctions import resolve_lakehouse_id

    if workspaceName == None:
        workspaceID = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceID)
    else:
        workspaceID = fabric.resolve_workspace_id(workspaceName)

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake mode.")
    else:
        dfE = fabric.list_expressions(dataset = datasetName, workspace = workspaceName)
        dfE_filt = dfE[dfE['Name']== 'DatabaseQuery']
        expr = dfE_filt['Expression'].iloc[0]

        matches = re.findall(r'"([^"]*)"', expr)

        sqlEndpointId = matches[1]

        dfI = fabric.list_items(workspace = workspaceName)
        dfI_filt = dfI[dfI['Id'] == sqlEndpointId]
        lakehouseName = dfI_filt['Display Name'].iloc[0]

        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

        return lakehouseName, lakehouseId
    
   

