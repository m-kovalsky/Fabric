import sempy
import sempy.fabric as fabric
import pandas as pd
from pyspark.sql import SparkSession

def get_lakehouse_columns(lakehouseName = None):

    """
    
    This function outputs a dataframe containing a list of tables/columns in a lakehouse. It is used for the schema check
    as well as for properly adding the calc tables to the new semantic model.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Lakehouse Name
            Table Name
            Column Name
            Full Column Name

            Note: 'Full Column Name' is in the following format: 'TableName'[ColumnName]
    """

    df = pd.DataFrame(columns=['Lakehouse Name', 'Table Name', 'Column Name', 'Full Column Name'])

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        dfItems = fabric.list_items()
        dfItems_filt = dfItems[(dfItems['Id'] == lakehouseId) & (dfItems['Type'] == 'Lakehouse')]
        lakehouseName = dfItems_filt['Display Name'].iloc[0]

    spark = SparkSession.builder.getOrCreate()
    
    tables = spark.sql(f"SHOW TABLES IN {lakehouseName}").collect()

    for t in tables:
        tName = t['tableName']
        columns = spark.sql(f"SHOW COLUMNS IN {lakehouseName}.{tName}").collect()
            
        for col in columns:
            cName = col.col_name
            tc = "'" + tName + "'[" + cName + "]"
            new_data = {'Lakehouse Name': lakehouseName, 'Table Name': tName, 'Column Name': cName, 'Full Column Name': tc}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df