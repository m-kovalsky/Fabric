import sempy
import sempy.fabric as fabric
import time

def refresh_semantic_model(datasetName, refreshType = 'full', workspaceName = None):

    """
    
    This function runs a full refresh of a given semantic model.
    
    Parameters:

        datasetName: The semantic model name.
        refreshType: The refresh type of the semantic model. Valid options: 'full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment'. Default value: 'full'
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    refreshTypes = ['full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment']

    if refreshType not in refreshTypes:
        print(f"ERROR: Invalid refresh type. Refresh type must be one of these values: {refreshTypes}.")
        return
        
    requestID = fabric.refresh_dataset(dataset = datasetName, workspace = workspaceName, refresh_type = refreshType)
    print(f"Refresh of the '{datasetName}' semantic model is in progress...")

    while True:
        requestDetails = fabric.get_refresh_execution_details(dataset = datasetName,refresh_request_id = requestID, workspace = workspaceName)
        status = requestDetails.status

        # Check if the refresh has completed
        if status == 'Completed':
            break

        time.sleep(3)

    print(f"Refresh of the '{datasetName}' semantic model is complete.")