import sempy
import sempy.fabric as fabric
import pandas as pd

def get_shared_expression(lakehouseName = None, workspaceName = None):

    """
    
    This function generates the shared expression statement for a given lakehouse and its SQL endpoint.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the
          lakehouse attached to the notebook.        
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns an M statement which can be used as the expression in the shared expression for a Direct Lake
        semantic model.
    """

    from .HelperFunctions import resolve_lakehouse_id

    df = pd.DataFrame(columns=['Lakehouse Name', 'Lakehouse ID', 'Workspace Name', 'Workspace ID', 'OneLake Tables Path', 'OneLake Files Path', 'SQL Endpoint Connection String', 'SQL Endpoint ID', 'SQL Endpoint Provisioning Status'])

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)
    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)
    
    client = fabric.FabricRestClient()

    #https://learn.microsoft.com/rest/api/fabric/articles/item-management/properties/lakehouse-properties
    response = client.get(f"/v1/workspaces/{workspaceId}/lakehouses/{lakehouseId}")
    responseJson = response.json()
    lakehouseName = responseJson['displayName']
    prop = responseJson['properties']
    oneLakeTP = prop['oneLakeTablesPath']
    oneLakeFP = prop['oneLakeFilesPath']
    sqlEPCS = prop['sqlEndpointProperties']['connectionString']
    sqlepid = prop['sqlEndpointProperties']['id']
    sqlepstatus = prop['sqlEndpointProperties']['provisioningStatus']

    new_data = {'Lakehouse Name': lakehouseName, 'Lakehouse ID': lakehouseId, 'Workspace Name': workspaceName, 'Workspace ID': workspaceId, 'OneLake Tables Path': oneLakeTP, 'OneLake Files Path': oneLakeFP, 'SQL Endpoint Connection String': sqlEPCS, 'SQL Endpoint ID': sqlepid, 'SQL Endpoint Provisioning Status': sqlepstatus}
    df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)  

    x = 'let\n\tdatabase = Sql.Database("' + sqlEPCS + '", "' + sqlepid + '")\nin\n\tdatabase'

    return x