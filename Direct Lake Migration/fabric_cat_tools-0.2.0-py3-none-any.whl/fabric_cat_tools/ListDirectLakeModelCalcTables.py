import sempy
import sempy.fabric as fabric
import pandas as pd

def list_direct_lake_model_calc_tables(datasetName, workspaceName = None):

    from .ListFunctions import list_tables
    from .ListFunctions import list_annotations

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    df = pd.DataFrame(columns=['Table Name', 'Source Expression'])

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake mode.")
    else:
        dfA = list_annotations(datasetName, workspaceName)
        dfT = list_tables(datasetName, workspaceName)
        dfA_filt = dfA[(dfA['Object Type'] == 'Model') & (dfA['Annotation Name'].isin(dfT['Name']))]

        for i,r in dfA_filt.iterrows():
            tName = r['Annotation Name']
            se = r['Annotation Value']

            new_data = {'Table Name': tName, 'Source Expression': se}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

        return df








    df = pd.DataFrame(columns=['Object Name', 'Parent Object Name', 'Object Type', 'Annotation Name', 'Annotation Value'])

    

    return df