import sempy
import sempy.fabric as fabric
import pandas as pd

def direct_lake_schema_compare(datasetName, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function checks that all tables/columns in a Direct Lake model exist in the lakehouse

    Parameters:

        datasetName: The semantic model name.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        lakehouseWorkspaceName: An optional parameter to set the workspace in which the lakehouse exists.

    Returns:

        This function returns 2 dataframes showing which tables/columns exist in the semantic model but do not exist
        in the lakehouse as currently mapped by their partition entity name and source column, respectively.
    """

    from .GetLakehouseColumns import get_lakehouse_columns

    if lakehouseWorkspaceName is None and lakehouseName is not None:
        print(f"If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName == None:
        lakehouseWorkspaceName = workspaceName

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)

    if any(r['Mode'] == 'DirectLake' for i, r in dfP.iterrows()):

        dfT = fabric.list_tables(dataset = datasetName, workspace = workspaceName)
        dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
        lc = get_lakehouse_columns(lakehouseName, lakehouseWorkspaceName)        
        
        dfT.rename(columns={'Type': 'Table Type'}, inplace=True)
        dfP_filt = dfP[dfP['Mode'] == 'DirectLake']
        dfC = pd.merge(dfC,dfP[['Table Name', 'Query']], on='Table Name', how='inner')
        dfC = pd.merge(dfC,dfT[['Name', 'Table Type']], left_on='Table Name', right_on='Name', how='inner')
        dfC['Full Column Name'] = "'" + dfC['Query'] + "'[" + dfC['Column Name'] + "]"
        dfC_filt = dfC[dfC['Table Type'] == 'Table']
        # Schema compare
        missingtbls = dfP_filt[~dfP_filt['Query'].isin(lc['Table Name'])]
        missingcols = dfC_filt[~dfC_filt['Full Column Name'].isin(lc['Full Column Name'])]

        if len(missingtbls) == 0:
            print('All tables validated')
        else:
            print('Missing tables...')
            display(missingtbls)
        if len(missingcols) == 0:
            print('All columns validated')
        else:
            print('Missing columns...')
            display(missingcols)
    else:
        print(f"The '{datasetName}' semantic model is not in Direct Lake mode.")