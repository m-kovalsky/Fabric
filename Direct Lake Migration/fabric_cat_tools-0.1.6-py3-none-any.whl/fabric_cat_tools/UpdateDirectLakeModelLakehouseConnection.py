import sempy
import sempy.fabric as fabric
import pandas as pd
from sempy.fabric._cache import _get_or_create_workspace_client
from sempy.fabric._client._connection_mode import ConnectionMode
import Microsoft.AnalysisServices.Tabular as TOM

def update_direct_lake_model_lakehouse_connection(datasetName, lakehouseName = None, workspaceName = None):

    """
    
    This function updates the connection of a Direct Lake model to a different lakehouse.

    Parameters:

        datasetName: The name of the semantic model.
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.        
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    from .GetSharedExpression import get_shared_expression

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        dfI = fabric.list_items(workspace = workspaceName)
        dfI_filt = dfI[(dfI['Id'] == lakehouseId) & (dfI['Type'] == 'Lakehouse')]
        lakehouseName = dfI_filt['Display Name'].iloc[0]

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']
    
    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model is not in Direct Lake. This function is only applicable to Direct Lake semantic models.")
    else:
        tom_server = _get_or_create_workspace_client(workspaceName).get_dataset_client(datasetName, ConnectionMode.XMLA)._get_connected_dataset_server(readonly=False)

        shEx = get_shared_expression(lakehouseName,workspaceName)

        for d in tom_server.Databases:
            if d.Name == datasetName:
                print(f"Updating the '{datasetName}' semantic model...")
                m = d.Model
                try:
                    m.Expressions['DatabaseQuery'].Expression = shEx
                    m.SaveChanges()
                    print(f"The expression in the '{datasetName}' semantic model has been updated to point to the '{lakehouseName}' lakehouse.")
                except:
                    print(f"ERROR: The expression in the '{datasetName}' semantic model was not updated.")



    

