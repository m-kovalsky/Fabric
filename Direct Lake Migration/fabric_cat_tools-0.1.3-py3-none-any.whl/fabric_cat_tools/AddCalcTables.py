import sempy
import sempy.fabric as fabric
import pandas as pd
import re
sempy.fabric._client._utils._init_analysis_services()
from sempy.fabric._cache import _get_or_create_workspace_client
from sempy.fabric._client._connection_mode import ConnectionMode
import Microsoft.AnalysisServices.Tabular as TOM
from sempy.fabric._client import DatasetXmlaClient
import System

def add_calc_tables(datasetName, newDatasetName, workspaceName = None):

    from .ListTables import list_tables
    from .ListAnnotations import list_annotations
    from .GetLakehouseColumns import get_lakehouse_columns

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    tom_server = _get_or_create_workspace_client(workspaceName).get_dataset_client(newDatasetName, ConnectionMode.XMLA)._get_connected_dataset_server(readonly=False)

    dfP = fabric.list_partitions(datasetName)
    dfT = list_tables(datasetName)
    dfC = fabric.list_columns(datasetName)
    lc = get_lakehouse_columns()
    dfT_filt = dfT[dfT['Type'] == 'Calculated Table']
    dfC_filt = dfC[(dfC['Table Name'].isin(dfT_filt['Name'])) & (dfC['Type'] == 'CalculatedTableColumn')]
    dfA = list_annotations(newDatasetName)
    dfA_filt = dfA[(dfA['Object Type'] == 'Model') & ~ (dfA['Annotation Value'].str.contains('NAMEOF'))]    

    for d in tom_server.Databases:
        if d.Name == newDatasetName:
            print(f"Updating '{d.Name}' based on '{datasetName}'...")
            m = d.Model
            exp = m.Expressions['DatabaseQuery']
            for tName in dfC_filt['Table Name'].unique():
                if tName.lower() in lc['Table Name'].values:
                    tbl = TOM.Table()
                    tbl.Name = tName

                    ep = TOM.EntityPartitionSource()
                    ep.Name = tName
                    ep.EntityName = tName.replace(' ', '_').lower() #lakehouse table names use underscores instead of spaces
                    ep.ExpressionSource = exp

                    part = TOM.Partition()
                    part.Name = tName
                    part.Source = ep
                    part.Mode = TOM.ModeType.DirectLake

                    tbl.Partitions.Add(part)

                    columns_in_table = dfC_filt.loc[dfC_filt['Table Name'] == tName, 'Column Name'].unique()

                    for cName in columns_in_table:
                        scName = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Source'].iloc[0]
                        cDataType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Data Type'].iloc[0]

                        if tName in dfA_filt['Annotation Name'].values:
                            pattern = r"\[([^\]]+)\]"
                    
                            matches = re.findall(pattern, scName) 
                            scName = matches[0]

                        tc = "'" + tName.lower() + "'[" + scName + "]"
                        if tc in lc['Full Column Name'].values:
                            lc_filt = lc[lc['Full Column Name'] == tc]
                            sc = lc_filt['Column Name'].iloc[0]
                            col = TOM.DataColumn()
                            col.Name = cName
                            col.SourceColumn = sc
                            col.DataType = System.Enum.Parse(TOM.DataType, cDataType)

                            try:
                                tbl.Columns.Add(col)
                                print(f"The '{tName}'[{cName}] column has been added.")
                            except:
                                print(f"ERROR: The '{tName}'[{cName}] column has not been added.")                    
                try:
                    m.Tables.Add(tbl)
                    print(f"The '{tName}' table has been added.")
                except:
                    print(f"ERROR: The '{tName}' table has not been added.")
                        
            m.SaveChanges()
            print(f"\nAll viable calculated tables have been added to the model.")