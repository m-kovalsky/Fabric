def create_daxfullobjectname(a,b):
        return "'" + a + "'[" + b + "]"